#include<stdio.h>
int main()
{
    int m,n;
    m=n=0;
    scanf("%d%d",&m,&n);
    printf("m=%d\nn=%d",m,n);
    return 0;
}