#include<stdio.h>
int main()
{
    int a,b,c;
    double x,y,z;
    a =3;b=4;c=5;
    x = 1.414;y=1.732;z=2.712;
    printf("a=%-7.db=%-7.dc=%-7.d\n",a,b,c);
    printf("x=%-7.3lfy=%-7.3lfz=%-7.3lf",x,y,z);
    return 0;

}
