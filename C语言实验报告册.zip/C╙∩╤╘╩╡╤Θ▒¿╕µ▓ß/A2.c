//求两个数的和、差、积、商
#include<stdio.h>
int main()
{
    float a,b;
    a = 2.0;
    b = 3.0;
    printf("%f\n",a+b);//和
    printf("%f\n",a-b);//差
    printf("%f\n",a*b);//积
    printf("%f\n",a/b);//商
    return 0;
}