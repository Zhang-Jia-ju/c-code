#include<stdio.h>
int main()
{
    int a,b,c;
    a=b=c=0;
    printf("ÇëĘäČëa,b,cľÄÖľ:");
    scanf("%d%d%d",&a,&b,&c);
    printf("X1=a+b+c= %d+ %d+ %d= %d\n",a,b,c,a+b+c);
    printf("X2=a+b+c= %d- %d- %d= %d",a,b,c,a-b-c);
    return 0;

}