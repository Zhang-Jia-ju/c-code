#include<stdio.h>
int main()
{
    int d1,d2,d3,d4;
    d1=d2=d3=d4=0;
    scanf("%d%d%d%d",&d1,&d2,&d3,&d4);
    printf("ASCII码对应字符如下:\n");
    printf("60='%c'\n61='%c'\n62='%c'\n63='%c'",d1,d2,d3,d4);
    return 0;
}