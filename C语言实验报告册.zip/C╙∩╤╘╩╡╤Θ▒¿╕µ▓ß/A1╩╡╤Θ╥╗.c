//求三个整数的和___10,15,20
#include<stdio.h>
int main()
{
    int a,b,c;
    int sum=0;
    a = 10;
    b = 15;
    c = 20;
    sum = a+b+c;
    printf("%d",sum);
    return 0;
}