#include<stdio.h>
int main()
{
    float c = 3.123456789;
    printf("%f",c);
    return 0;//输出结果从第七位被截断，四舍五入到第6位
}